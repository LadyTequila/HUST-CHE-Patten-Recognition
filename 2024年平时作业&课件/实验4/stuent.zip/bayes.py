# 构建网络
from pgmpy.models import BayesianNetwork
from pgmpy.factors.discrete import TabularCPD
from pgmpy.inference import VariableElimination

cancer_model = BayesianNetwork([(XXXX),  # eg.('start', 'end')
                                (XXXX),
                                (XXXX),
                                (XXXX)])

# TabularCPD通过TabularCPD构造条件概率分布CPD（condition probability distribution）表格
# 最后将CPD数据添加到贝叶斯网络结构中，完成贝叶斯网络的构造。
# 设置参数
poll = TabularCPD(variable='Pollution', variable_card=2,
                      values=[[0.9], [0.1]])
# variable:节点变量名称是'Pollution', variable_card:变量的可能结果有2种(0 or 1)
# values:两种结果的概率值
smoke = TabularCPD(XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX  # 请为'Smoker'设置参数
                    XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX)
cancer = TabularCPD(variable='Cancer', variable_card=2,  # Cancer有两个父节点，values需要输入2*2=4个条件概率
                        values=[[XXXXXXXXXXXXXXXXXXXXXXXX],  # Cancer=0的四种条件概率[p(c0|a0,b0), p(c0|a0,b1), p(c0|a1,b0), p(c0|a1,b1)]
                                [XXXXXXXXXXXXXXXXXXXXXXX]],  # Cancer=1的四种条件概率
                        evidence=[XXX, XXX],  # evidence:父节点变量名称
                        evidence_card=[X, X])  # evidence中每一个父节点对应的结果数量
xray = TabularCPD(XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX  # 请为'Xray'设置参数
                      XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX   # values
                      XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX)  # evidence,evidence_card
dysp = TabularCPD(XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX   # 请为'Dyspnoea'设置参数
                      XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX   # values
                      XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX)  # evidence,evidence_card
cancer_model.add_cpds(poll, smoke, cancer, xray, dysp)

# 测试网络结构是否正确
print(cancer_model.check_model())
# 变量消除法是精确推断的一种方法.

# 使用建立好的贝叶斯网络进行推理
asia_infer = VariableElimination(cancer_model)
q = asia_infer.query(variables=[XXXXX], evidence={XXXXXXX: X, XXXXXXX: X})  # 计算evidence前提下的variables的概率
print(q)
