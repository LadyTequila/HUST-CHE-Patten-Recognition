# 维特比算法
import time


def viterbi(observation_seq, states, start_p, trans_p, emit_p):
    """
    形参params:
        observation_seq: observation_set: 观测序列,即朋友圈动态
        states: state_set: 隐藏状态:每一天有可能呆在的地点, BJ or YN
        start_p: start_probability
        trans_p: transition_probability
        emit_p:  emission_probability
    return
        result
        举例example:
        result {当前节点:(路径最高得分,来自的上一个节点)} = [{A:(0.1, None), B:(0.3, None)},   # T1时刻
                                                        {A:(0.04, B), B:(0.004, A)},      # T2时刻
                                                        {A:(0.0038, A), B:(0.009, B)}]    # T3时刻

        e.g:
        A:(0.04, B): 当前节点A,最高得分是0.04;上一个节点B(0.04是从A走到A和从B走到A二者得分较大值)
        想取出result中的值需要使用result[0][A][0]=0.1 提示python中的角标是从0开始，所以第一个元素角标是0
    """
    result = [{}]  # 存放结果dp,每个元素是一个字典,字典的形式 cur_state:(score, pre_state)
    # cur_state:当前状态; score:当前状态下的概率值; pre_state上一个状态
    # 计算第一个时刻
    for s in states:  # ('BJ', 'YN'),例如: result[0]["BJ"], 第[0]维key = "BJ"的结果
        result[0][s] = (XXXXXXXXXXXXXXXXXXXXXXXXXXX, None)  # 第[0]时刻状态s对应的value(score)为: (起始状态的概率×发射概率, None).

    # t代表下标index
    for t in range(1, len(observation_seq)):
        result.append({})  # 准备t时刻的结果存放字典，形式同上

        # s代表字典的key,即当前的位置
        for s in states:  # 对于每一个t时刻状态s,获取t-1时刻每个状态s_pre的p,公式：result[第几时刻][地点][第几个值]
            # 结合由t-1时刻隐藏状态转化为t时刻隐藏状态的转移概率trans_p[t-1时刻s][t时刻s]
            # 和s状态至obs的发散概率emit_p[t时刻s][t时刻观测值]
            # 计算t时刻s状态的最大概率，并记录该概率的来源状态s_pre
            # max()内部比较的是一个tuple:(p,s_pre),max比较tuple内的第一个元素值
            # 公式：得分=历史得分result[][][]*状态转移得分trans_p[][]*发射得分emit_p[][]
            result[t][s] = max([XXXXXXXXXXXXXXXXXXXXXX, s_pre)for s_pre in states])  # s_pre为t-1时刻m个状态

    return result


# 状态的样本空间
state_set = ('BJ', 'YN')                    # 北京,云南

# 观测的样本空间
observation_set = ('烤鸭', '米粉', '饭')    # 每天吃的东西

# 起始的状态概率
start_probability = {'BJ': 0.6, 'YN': 0.4}  # 小明一般在北京或者在云南

# 状态转移概率矩阵A
transition_probability = {
  'BJ': {'BJ': 0.3, 'YN': 0.7},             # 今天在北京时,明天留在北京和去云南的概率
  'YN': {'YN': 0.2, 'BJ': 0.8},             # 今天在云南时,明天去在北京和留云南的概率
}

# 状态->观测的发射概率矩阵B
emission_probability = {
  'BJ': {'烤鸭': 0.5, '米粉': 0.2, '饭': 0.3},  # 在北京时,吃各种食物的概率
  'YN': {'烤鸭': 0.1, '米粉': 0.5, '饭': 0.4},  # 在云南时,吃各种食物的概率
}

observation_seq = ["烤鸭", "米粉", "饭", "烤鸭", "饭"]  # 朋友圈5天动态

# 测试并输出结果
result = viterbi(observation_seq, state_set, start_probability,
                 transition_probability, emission_probability)
for t, res in enumerate(result):
    print("起始状态S到 {} 时刻每个状态的最优路径得分 及对应的父节点：{}".format(t+1, res))


def _get_best_paths(result):  # 回溯,找到全局最优解
    """
    params:
        result: like [{}], 每一个字典的形式是 state:(p, pre_state), p is path_score
    """
    best_path = []

    last_dict = result[-1]  # 取到t5时刻的最终结果{'BJ':(0.00042336,'YN'),'YN':(0.0010584,'BJ')}

    sorted_list = sorted(last_dict.items(), key=lambda last_dict: last_dict[1],
                         reverse=True)  # last_dict.items(): 返回(键:值)元祖数组
    # 并按第[1]维排序,即(0.00042336,'YN')或(0.0010584,'BJ')

    last_state, (final_score, pre_state) = sorted_list[0]  # sorted_list[0] = 'YN':(0.0010584, 'BJ')
    best_path.append(last_state)  # 把'YN'压到best_path里

    for i in range(len(result) - 2, -1, -1):  # 此时pre_state = 'BJ',拿到上一时刻t3中找pre_state
        best_path.append(pre_state)
        dict_ = result[i]  # result[3] ={'BJ':(0.00378,'BJ'),'YN':(0.001764,'BJ')}
        pre_state = dict_[pre_state][1]  # 找到'BJ'对应的pre_state = 'BJ'

    best_path.reverse()  # 因为压入的顺序是从后往前,即从t5到t1压入的,所以最后还得倒过来

    return best_path, final_score


start_time = time.perf_counter()  # 开始时间

result = viterbi(observation_seq, state_set, start_probability,
                 transition_probability, emission_probability)

best_path, final_score = _get_best_paths(result)
over_time = time.perf_counter()  # 结束时间

print("spend time: {}s".format(over_time - start_time))
print("best path:{}".format(str(best_path)))
print("max score:{}".format(final_score))
