# 暴力穷举法
import numpy as np
import time

# 状态的样本空间
state_set = ('BJ', 'YN')                           # 北京,云南

# 观测的样本空间
observation_set = ('烤鸭', '米粉', '饭')           # 每天吃的东西

# 起始的状态概率
start_probability = {'BJ': 0.6, 'YN': 0.4}         # 初始小明在北京或者在云南的概率

# 状态转移概率矩阵A:(可以画一个2×2的矩阵)
transition_probability = {
  'BJ': {'BJ': 0.3, 'YN': 0.7},                    # 今天在北京时,明天留在北京和去云南的概率
  'YN': {'YN': 0.2, 'BJ': 0.8},                    # 今天在云南时,明天去在北京和留云南的概率
}

# 状态->观测的发射概率矩阵B:(可以画一个2×3的矩阵)
emission_probability = {
  'BJ': {'烤鸭': 0.5, '米粉': 0.2, '饭': 0.3},     # 在北京时,吃各种食物的概率
  'YN': {'烤鸭': 0.1, '米粉': 0.5, '饭': 0.4},     # 在云南时,吃各种食物的概率
}

# 观测序列
observation_seq = ["烤鸭", "米粉", "饭", "烤鸭", "饭"]         # 把朋友圈5天动态存成列表形式


def _all_sequence(unique_val_set, repeat):
    """
    形参params:
        unique_val_set: 一次实验，所有可能状态的集合(本实验只有"BJ","YN"两种可能)
        repeat: 实验次数(本实验是指发朋友圈的天数)
    实参return:
        paths:一个列表，存储的每个元素是一个路径，列表长度是所有可能路径个数

        Example:
        if：
            unique_val_set = ("A", "B")
            repeat = 2
        then:
            paths = [["A", "A"],
                    ["A", "B"],
                    ["B", "A"],
                    ["B", "B"]]
    """

    # 用的是迭代法(iterative method),每次往上一轮的每个结果里加当前的数字nums[i]
    paths = []  # 刚开始是一次实验也没做的结果
    for i in range(repeat):  # 从第1次做到第repeat次实验
        last_paths = paths  # 先把上次实验的结果赋值给last_paths
        paths = []  # reset一下本轮实验结果的路径列表

        if len(last_paths) == 0:  # 第一次实验
            for val in unique_val_set:  # 只有两种可能,要么是'A',要么是'B'
                a_path = [val]  # 把[A]添加到a_path里
                paths.append(a_path)

        else:  # 不是第一次实验,假设last_paths = [[A],[B]]
            for a_last_path in last_paths:  # 取出上次实验后的每条路径last_paths=[A] or [B]
                for val in unique_val_set:  # 再把unique_val_set里每种可能[A]or[B]加到上一次实验的每个结果里
                    a_path = a_last_path + [val]  # 例如val=[A],把[A]加到[A]里,把[A]加到[B]里; 又当val=[B],把[B]加到[A]里,把[B]加到[B]里;
                    paths.append(a_path)  # paths = [[A,A],[B,A],[A,B],[B,B]]

        del last_paths  # 删除上次实验的结果

    return paths


"""
# 测试
paths = _all_sequence(("A", "B"), repeat = 2)                  # 所有可能的状态集合为"A"和"B"两种可能,一共发了3天的朋友圈
for path in paths:
    print(path)
 """


"""
# 计算得分
e.g：
由观测状态`observation_seq = ["烤鸭", "米粉", "饭", "烤鸭", "饭"]`和所有路径`path = ["BJ", "BJ", "BJ", "BJ", "BJ"]`
  
可知得分为：P(第一天在北京) * P(在北京吃烤鸭) × P(从北京到北京) * P(在北京吃米粉) × P(从北京到北京) * P(在北京吃饭)...
  
即得分score = P(day1 in "BJ") * P("BJ" eat "烤鸭") × P(day2 in "BJ" | day1 in "BJ") * P("BJ" eat "米粉") ... 
            × P(day5 in "BJ" | day4 in "BJ") * P("BJ" eat "饭")

"""


def guess_places(observation_seq, state_set, start_probability, transition_probability,
                 emission_probability):
    """
    params:
        observation_seq：观测序列。||一个列表，列表元素是朋友圈的一个状态 ["烤鸭", "米粉", "饭", "烤鸭", "饭"]
        state_set：状态的样本空间。|| 朋友圈的所有可能的状态 ["BJ", "YN"]
        start_probability：起始的状态概率。
        transition_probability：状态转移概率
        emission_probability：发射概率

    return:
        (paths, scores)： 两个列表，对应所有可能的状态及其得分

        example:
            paths = [["A", "A"],
                     ["A", "B"],
                     ["B", "A"],
                     ["B", "B"]]
            scores = [0.5, 0.2, 0.1, 0.2]

            解释:0.5对应["A", "A"],0.2对应["A", "B"],0.1对应["B", "A"],0.2对应["B", "B"]
    从字典中取值的方法例子
        transition_probability = {
        'BJ': {'BJ': 0.3, 'YN': 0.7},
        'YN': {'YN': 0.2, 'BJ': 0.8},
        ｝
        transition_probability[BJ][YN] = 0.7
    """
    how_many_days = len(observation_seq)  # 一共几天
    paths = _all_sequence(state_set, how_many_days)  # unique_set=state_set,repeat=days,得到所有可能的路径,从中找出概率最大的

    # 计算每条路径得分,分为两步: 1. 状态转移概率的得分; 2.得到observation_seq的发射概率得分
    scores = []  # 用于存放每条路径的得分
    for path in paths:  # 遍历2^{5}=32条路径里的每条路径
        for i, place in enumerate(path):  # i是下标,place=BJ or YN
            if i == 0:  # 如果是第一天的话要用起始概率矩阵而不用状态转移概率矩阵
                score = XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX  # P(第一天在北京)*P(在北京吃烤鸭)

            else:  # 从第二天开始
                pre_place = path[i - 1]  # 得到前一天的地点
                score = XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX  # 得分=历史得分*状态转移得分*发射得分

        scores.append(score)

    return (paths, scores)  # 返回"所有路径和所有得分"元祖,到时候用zip一组一组地取


start_time = time.perf_counter()  # 开始时间

paths, scores = guess_places(observation_seq, state_set, start_probability,
                             transition_probability, emission_probability)
over_time = time.perf_counter()  # 结束时间

print("spend time: {}s".format(over_time - start_time))                    # 返回用时
print("max score:{}".format(max(scores)))                                  # 返回最大的得分
print("the best path:{}".format(str(paths[np.argmax(scores)])))            # np.argmax(scores):返回得分最大路径的下标,再去paths里找

print("all paths number:{}".format(len(paths)))                            # 返回共有几条路径
# 遍历所有路径，查看得分
# for path, score in zip(paths, scores):
#     print("path = {}, score = {}".format(str(path), score))


